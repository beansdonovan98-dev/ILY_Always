import { useCallback, useEffect, useRef, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, View, ViewStyle } from 'react-native';
import { useFocusEffect } from 'expo-router';

import { AppText as Text } from '@/components/AppText';
import { LeafBorder } from '@/components/CannabisLeaf';
import { MylarPouch } from '@/components/MylarPouch';
import { Celebration } from '@/components/Celebration';
import { useAppTheme } from '@/hooks/useAppTheme';
import { useUsage } from '@/contexts/UsageContext';

import { getCoupleId } from '@/lib/couple';
import { useTabLabel } from '@/hooks/useTabLabel';
import { localDateKey } from '@/lib/days';
import { subscribeMany } from '@/lib/subscribe';
import { markActivity } from '@/lib/activity';
import {
  Cadence,
  Chore,
  DAILY_CHORES,
  FOCUS_AREAS,
  Streaks,
  TWO_DAY_CHORES,
  WEEKLY_CHORES,
  allDone,
  computeStreaks,
  currentCycleKey,
  focusAreaForWeek,
  isDone,
  isFocusHiddenToday,
  loadChecks,
  sundayOfToday,
  toggleCheck,
  twoDayDueToday,
} from '@/lib/cleaning';

export default function CleaningScreen() {
  const theme = useAppTheme();
  const cleaningTitle = useTabLabel('cleaning', 'Get It Squeaky Clean');
  const { currentUser } = useUsage();

  const [coupleId, setCoupleId] = useState('');
  const [checks, setChecks] = useState<Record<string, boolean>>({});
  const [streaks, setStreaks] = useState<Streaks>({ daily: 0, twoDay: 0, weekly: 0 });
  const [celebration, setCelebration] = useState<{ mode: 'small' | 'big' | 'mega'; message: string } | null>(null);
  const celebrated7 = useRef(false);

  useEffect(() => {
    if (streaks.daily >= 7 && !celebrated7.current) {
      celebrated7.current = true;
      setCelebration({ mode: 'big', message: `7 DAYS CLEAN. The lair has never looked this filthy-sexy. 👑` });
    }
    if (streaks.daily < 7) celebrated7.current = false;
  }, [streaks.daily]);

  const today = localDateKey();
  const focusHidden = isFocusHiddenToday();
  const focusArea = focusAreaForWeek(sundayOfToday());
  const twoDayDue = twoDayDueToday(today);

  const load = useCallback(async () => {
    const cid = await getCoupleId();
    setCoupleId(cid);
    const loaded = await loadChecks(cid);
    setChecks(loaded);
    setStreaks(computeStreaks(loaded));
  }, []);

  // Live: her check-offs land here the second she taps them.
  useEffect(() => {
    if (!coupleId) return;
    const unsub = subscribeMany(['cleaning_checks'], coupleId, () => void load());
    return unsub;
  }, [coupleId, load]);

  useFocusEffect(
    useCallback(() => {
      void load();
    }, [load])
  );

  const cadenceComplete = (next: Record<string, boolean>, cadence: Cadence, chores: Chore[]) =>
    allDone(next, cadence, chores, currentCycleKey(cadence, today));

  const toggle = async (cadence: Cadence, chore: Chore) => {
    void markActivity('cleaning', currentUser, coupleId);
    const cycleKey = currentCycleKey(cadence, today);
    const next = await toggleCheck(coupleId, checks, cadence, chore.id, cycleKey);
    setChecks(next);
    setStreaks(computeStreaks(next));

    const wasDone = isDone(checks, cadence, chore.id, cycleKey);
    const nowDone = isDone(next, cadence, chore.id, cycleKey);
    if (nowDone && !wasDone) {
      const dailyDoneNow = cadenceComplete(next, 'daily', DAILY_CHORES);
      const twoDayDoneNow = cadenceComplete(next, 'twoDay', TWO_DAY_CHORES);
      const weeklyDoneNow = cadenceComplete(next, 'weekly', WEEKLY_CHORES);
      const focusDoneNow =
        !focusHidden && focusArea.tasks.length > 0 && allDone(next, 'focus', focusArea.tasks, cycleKey);

      if (dailyDoneNow && twoDayDoneNow && weeklyDoneNow) {
        setCelebration({ mode: 'mega', message: 'EVERYTHING DONE. This house is a temple today.' });
      } else if (weeklyDoneNow) {
        setCelebration({ mode: 'big', message: `Weekly reset complete — the nest is royal` });
      } else if (twoDayDoneNow) {
        setCelebration({ mode: 'big', message: `Every-other-day list slammed` });
      } else if (dailyDoneNow) {
        setCelebration({ mode: 'small', message: `All daily chores done — love that for us` });
      } else if (focusDoneNow) {
        setCelebration({ mode: 'small', message: `${focusArea.name} deep-cleaned — filthy clean` });
      }
    }
  };

  const renderCheckRow = (cadence: Cadence, chore: Chore, extra?: ViewStyle) => {
    const cycleKey = currentCycleKey(cadence, today);
    const done = isDone(checks, cadence, chore.id, cycleKey);
    return (
      <Pressable
        key={chore.id}
        onPress={() => toggle(cadence, chore)}
        style={[
          styles.checkRow,
          { borderColor: theme.borderColor },
          done && { backgroundColor: theme.accentSoft },
          extra,
        ]}>
        <Text style={[styles.checkMark, { color: theme.accentColor }]}>{done ? '✓' : '○'}</Text>
        <Text style={[styles.checkLabel, done && styles.checkLabelDone]}>{chore.label}</Text>
      </Pressable>
    );
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Text style={styles.title}>{cleaningTitle}</Text>
      <Text style={[styles.subtitle, { color: theme.subtitleColor }]}>
        Keeping our lair irresistibly filthy-clean for mischief
      </Text>

      {/* Deep clean focus — hidden until Sunday 12:00 AM */}
      <MylarPouch title={<Text style={styles.cardTitle}>Sunday Deep Dive</Text>} defaultStrain="GRANDDADDY P." stampRight="THC: 28.5%">
        <LeafBorder color={theme.leafColor} />
        <Text style={[styles.cardHint, { color: theme.subtitleColor }]}>
          One room gets the full filthy treatment each week
        </Text>

        {focusHidden ? (
          <View style={styles.placeholder}>
            <Text style={styles.placeholderText}>
              The deep clean drops Sunday at 12:00 AM — smokescreen until then
            </Text>
          </View>
        ) : (
          <>
            <View style={styles.focusHead}>
              <Text style={styles.focusTitle}>
                {focusArea.name} — this week
              </Text>
              <View style={styles.focusBar}>
                <View
                  style={[
                    styles.focusBarFill,
                    {
                      backgroundColor: theme.accentColor,
                      width: `${
                        (focusArea.tasks.filter((t) =>
                          isDone(checks, 'focus', t.id, currentCycleKey('focus', today))
                        ).length /
                          focusArea.tasks.length) *
                        100
                      }%`,
                    },
                  ]}
                />
              </View>
            </View>
            {focusArea.tasks.map((t) => renderCheckRow('focus', t))}
          </>
        )}
      </MylarPouch>

      {/* Daily */}
      <MylarPouch title={<Text style={styles.cardTitle}>Daily Hustle</Text>} defaultStrain="SOUR DIESEL" stampRight="THC: 21.5%">
        <LeafBorder color={theme.leafColor} />
        <Text style={[styles.cardHint, { color: theme.subtitleColor }]}>
          A little effort every day keeps the dirty boys away
        </Text>
        <Text style={styles.streakLine}>{streaks.daily}-day streak</Text>
        <View style={styles.twoCol}>
          {DAILY_CHORES.map((c) => renderCheckRow('daily', c, styles.twoColItem))}
        </View>
      </MylarPouch>

      {/* Every 2 days */}
      <MylarPouch title={<Text style={styles.cardTitle}>Every Other Day</Text>} defaultStrain="BLUE DREAM" stampRight="THC: 22.5%">
        <LeafBorder color={theme.leafColor} />
        <Text style={[styles.cardHint, { color: theme.subtitleColor }]}>
          {twoDayDue
            ? 'Due today — reset the lair, no excuses, gorgeous'
            : 'Not due today. Breathe, hold it in'}
        </Text>
        <Text style={styles.streakLine}>{streaks.twoDay}-cycle streak</Text>
        {TWO_DAY_CHORES.map((c) => renderCheckRow('twoDay', c))}
      </MylarPouch>

      {/* Weekly */}
      <MylarPouch title={<Text style={styles.cardTitle}>The Weekly Ritual</Text>} defaultStrain="GRANDDADDY P." stampRight="THC: 25.5%">
        <LeafBorder color={theme.leafColor} />
        <Text style={[styles.cardHint, { color: theme.subtitleColor }]}>
          The Sunday ritual that keeps our nest fit for royalty
        </Text>
        <Text style={styles.streakLine}>{streaks.weekly}-week streak</Text>
        {WEEKLY_CHORES.map((c) => renderCheckRow('weekly', c))}
      </MylarPouch>

      {/* 7-day daily-cleaning tracker */}
      <MylarPouch title={<Text style={styles.cardTitle}>7-Day Cleaning Tracker</Text>} defaultStrain="BLUE DREAM" stampRight="THC: 22.5%">
        <LeafBorder color={theme.leafColor} />
        <Text style={[styles.cardHint, { color: theme.subtitleColor }]}>
          Do the Daily Hustle 7 days straight — Sunday is day 1 — and the lair celebrates with you.
        </Text>
        <View style={styles.streakRow}>
          {Array.from({ length: 7 }, (_, i) => {
            const filled = i < Math.min(streaks.daily, 7);
            return (
              <View
                key={i}
                style={[
                  styles.streakDot,
                  filled
                    ? { backgroundColor: theme.accentColor, borderColor: theme.accentColor }
                    : { backgroundColor: 'rgba(255,255,255,0.5)', borderColor: theme.borderColor },
                ]}>
                <Text style={[styles.streakDotText, filled && { color: '#FFFFFF' }]}>{filled ? '✓' : '·'}</Text>
              </View>
            );
          })}
        </View>
        <Text style={styles.streakText}>🔥 {streaks.daily}/7 days — Sunday is day 1</Text>
        {streaks.daily >= 7 && <Text style={styles.bigCelebration}>7 DAYS CLEAN. The lair has never looked this filthy-sexy. 👑</Text>}
      </MylarPouch>

      <Celebration
        mode={celebration?.mode ?? null}
        message={celebration?.message ?? ''}
        onDone={() => setCelebration(null)}
      />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 24, paddingBottom: 60, alignItems: 'stretch', gap: 36, maxWidth: '100%' },
  title: { fontSize: 34, fontWeight: '800', marginBottom: 4 },
  subtitle: { fontSize: 17, fontStyle: 'italic', lineHeight: 24, marginBottom: 4 },
  card: {
    padding: 18,
    borderRadius: 22,
    shadowColor: '#000',
    shadowOpacity: 0.06,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 3 },
    elevation: 3,
  },
  cardTitle: { fontSize: 19, fontWeight: '800', marginBottom: 4 },
  cardHint: { fontSize: 13, fontStyle: 'italic', opacity: 0.72, marginBottom: 10, lineHeight: 18 },
  streakLine: { fontSize: 13, fontWeight: '800', opacity: 0.8, marginBottom: 8 },
  streakRow: { flexDirection: 'row', gap: 6, marginTop: 4 },
  streakDot: {
    width: 26, height: 26, borderRadius: 13, borderWidth: 1,
    alignItems: 'center', justifyContent: 'center',
  },
  streakDotText: { fontSize: 13, fontWeight: '800' },
  streakText: { fontSize: 14, fontWeight: '800', marginTop: 8 },
  bigCelebration: { fontSize: 16, fontWeight: '900', marginTop: 8, color: '#E11D48' },
  placeholder: { alignItems: 'center', paddingVertical: 24, gap: 10 },
  placeholderEmoji: { fontSize: 44 },
  placeholderText: { fontSize: 14, fontStyle: 'italic', opacity: 0.7, textAlign: 'center', lineHeight: 20 },
  focusHead: { marginBottom: 4 },
  focusTitle: { fontSize: 16, fontWeight: '800' },
  focusBar: { height: 8, borderRadius: 4, backgroundColor: 'rgba(58,42,46,0.1)', marginTop: 8, overflow: 'hidden' },
  focusBarFill: { height: 8, borderRadius: 4 },
  checkRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 8,
    paddingHorizontal: 10,
    marginTop: 6,
    borderRadius: 10,
    borderWidth: 1,
    backgroundColor: 'rgba(255,255,255,0.45)',
  },
  twoCol: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  twoColItem: { flex: 1, minWidth: '47%' },
  checkCircle: {
    width: 32,
    height: 32,
    borderRadius: 16,
    borderWidth: 2,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.6)',
  },
  checkMark: { fontSize: 17, fontWeight: '800' },
  checkLabel: { fontSize: 15, fontWeight: '600', flex: 1 },
  checkLabelDone: { opacity: 0.55, textDecorationLine: 'line-through' },
});
