import { readFileSync } from 'node:fs';
const s = readFileSync('supabase/functions/ai-image-edit/styleBuckets.ts', 'utf8');
const i = s.indexOf("id: 'comic-book'");
const sub = s.slice(i, i + 40);
console.log([...sub].map((c) => `${c}:${c.charCodeAt(0).toString(16)}`).join(' '));
