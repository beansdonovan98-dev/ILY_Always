import { readFileSync } from 'node:fs';
const s = readFileSync('supabase/functions/ai-image-edit/styleBuckets.ts', 'utf8');
const i = s.indexOf("id: 'comic-book'");
const sub = s.slice(i, i + 60);
console.log(JSON.stringify(sub));
const re = /id:\s*'([a-z0-9-]+)',\s*bucket:\s*'([a-z_]+)'/g;
console.log('on substring:', [...sub.matchAll(re)].length);
// find every "bucket: '" occurrence count
console.log('bucket occurrences:', [...s.matchAll(/bucket:\s*'/g)].length);
