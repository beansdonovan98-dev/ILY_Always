import { readFileSync } from 'node:fs';
const s = readFileSync('supabase/functions/ai-image-edit/styleBuckets.ts', 'utf8');
const m = [...s.matchAll(/id:\s*'([a-z0-9-]+)',\s*bucket:\s*'([a-z_]+)'/g)];
const b = {};
for (const x of m) b[x[2]] = (b[x[2]] || 0) + 1;
console.log('matches', m.length, b);
console.log('has comic-book:', s.includes("id: 'comic-book', bucket: 'anime_2d_toon'"));
const i = s.indexOf("id: 'comic-book'");
console.log(JSON.stringify(s.slice(i - 40, i + 90)));
