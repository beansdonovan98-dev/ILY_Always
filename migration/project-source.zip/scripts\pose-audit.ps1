param(
  [int]$Start = 1,
  [int]$Count = 150,
  [string]$Style = 'adult-anime',
  [string]$Light = 'teal',
  [string]$OutDir = 'C:\Users\ashle\OneDrive\Desktop\ILY_Always\audit\poses',
  [string]$PoseFile = '',
  [switch]$Styles,
  [string]$StyleList = ''
)

$ErrorActionPreference = 'Stop'
$anon = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Ind1ZmVvdmNtdW5mcXRqYW51ZHRhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTQwMTgyNjAsImV4cCI6MjEwOTU5NDI2MH0.jg8MaFb-x7fUoy_TWKahBVvaIA6UuwDznvwo0P9yyo"
$h = @{ apikey = $anon; Authorization = "Bearer $anon"; 'Content-Type' = 'application/json' }
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null

function Get-Poses {
  $src = Get-Content 'C:\Users\ashle\OneDrive\Desktop\ILY_Always\supabase\functions\ai-image-edit\styleBuckets.ts'
  $start = ($src | Select-String -Pattern '^export const POSE_OPTIONS = \[$').LineNumber
  $end = 0
  for ($i = $start; $i -lt $src.Count; $i++) { if ($src[$i].Trim() -eq '];') { $end = $i; break } }
  $rows = @()
  $n = 0
  for ($i = $start; $i -lt $end - 1; $i++) {
    $line = $src[$i].Trim()
    if (-not $line.StartsWith("'")) { continue }
    $n++
    $rows += [pscustomobject]@{ n = $n; text = $line.TrimStart("'").TrimEnd("',") }
  }
  return $rows
}

$prevEap = $ErrorActionPreference
$ErrorActionPreference = 'SilentlyContinue'
$jsonLine = cmd /c "npx supabase projects api-keys --project-ref wufeovcmunfqtjanudta 2>nul" | Where-Object { $_ -match '^\s*\{' } | Select-Object -Last 1
$ErrorActionPreference = $prevEap
$json = $jsonLine | ConvertFrom-Json
$key = ($json.keys | Where-Object { $_.name -eq 'service_role' } | Select-Object -First 1).api_key
$b64 = [Convert]::ToBase64String([IO.File]::ReadAllBytes('C:\Users\ashle\AppData\Local\Temp\opencode\front-source.jpg'))

$jobs = @()
if ($Styles) {
  $list = if ($StyleList) { $StyleList -split ',' } else {
    @('adult-anime','cartoon','powerpuff-girls','sticker-pack','anime-cyberpunk','anime-fantasy','anime-school','anime-succubus','anime-mecha','anime-idol','anime-horror','anime-samurai','anime-retro','anime-ghibli')
  }
  foreach ($s in $list) { $jobs += [pscustomobject]@{ name = "style-$($s.Trim())"; style = $s.Trim(); pose = 'standing with her weight on one hip, a lit joint in one hand, the other hand on her hip, looking at the viewer' } }
} else {
  $all = Get-Poses
  $slice = $all | Where-Object { $_.n -ge $Start -and $_.n -lt ($Start + $Count) }
  foreach ($p in $slice) { $jobs += [pscustomobject]@{ name = ('pose-{0:d3}' -f $p.n); style = $Style; pose = $p.text } }
}

foreach ($job in $jobs) {
  $out = Join-Path $OutDir "$($job.name).png"
  if (Test-Path $out) { Write-Output "$($job.name) skip"; continue }
  $rid = "audit-$($job.name)-" + [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
  $body = @{
    action = 'style_start'; request_id = $rid; styleMode = $job.style
    imageBase64 = $b64; subject = 'wife'; isNude = $true
    poseMode = 'custom'; posePrompt = $job.pose; lightColor = $Light
  } | ConvertTo-Json -Compress
  try {
    $null = Invoke-RestMethod -Uri 'https://wufeovcmunfqtjanudta.supabase.co/functions/v1/ai-image-edit' -Method Post -Headers $h -Body $body -TimeoutSec 120
  } catch {
    Write-Output "$($job.name) start-fail $($_.Exception.Message)"; continue
  }
  $sb = @{ action = 'style_status'; request_id = $rid } | ConvertTo-Json -Compress
  $st = ''
  for ($i = 0; $i -lt 100; $i++) {
    Start-Sleep -Seconds 6
    try {
      $s = Invoke-RestMethod -Uri 'https://wufeovcmunfqtjanudta.supabase.co/functions/v1/ai-image-edit' -Method Post -Headers $h -Body $sb -TimeoutSec 30
      if ($s.status -in @('COMPLETED','FAILED','CANCELLED','TIMED_OUT')) { $st = $s.status; break }
    } catch { }
  }
  if ($st -eq 'COMPLETED') {
    try {
      Invoke-WebRequest -Uri "https://wufeovcmunfqtjanudta.supabase.co/storage/v1/object/couple-private/default-couple/ai-edits/$rid.png" -Headers @{ Authorization = "Bearer $key"; apikey = $key } -OutFile $out -TimeoutSec 90
      Write-Output "$($job.name) saved"
    } catch { Write-Output "$($job.name) download-fail" }
  } else {
    Write-Output "$($job.name) failed $st"
  }
}
